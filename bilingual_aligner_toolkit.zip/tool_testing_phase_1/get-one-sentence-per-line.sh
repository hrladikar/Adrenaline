export scriptdir=`dirname $0`

java  -mx500m -cp "$scriptdir/*:" edu.stanford.nlp.process.DocumentPreprocessor -tokenizerOptions "americanize=false, escapeForwardSlashAsterisk=false"  $1
