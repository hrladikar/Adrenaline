#Create a folder Aligned.. aligned files will be accessed through path provided and generated in that folder..

for i in `seq 1 912`;
do
	./align-eng-hin.out Arrow/a_eng_sen_$i.txt hin_sen_$i eng_sen_$i Aligned/anchor_$i.txt;
done
