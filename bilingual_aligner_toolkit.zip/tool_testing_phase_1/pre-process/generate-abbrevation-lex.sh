sed -e 's/\./\\./g' abbrevations > abbrevations_tmp
var=`cat abbrevations_tmp`
for i in $var;
do

echo "$i	{	*str='\0';"	>> abbrevations.lex
echo "		while((len=strcspn(yytext,\".\")) < strlen(yytext))"	>> abbrevations.lex
echo "		{"	>> abbrevations.lex
echo "		   strncat(str,yytext,len);"	>> abbrevations.lex
echo "		   yytext=yytext+len+1;"	>> abbrevations.lex
echo "		   strcat(str,\"ABBR-Dot\");"	>> abbrevations.lex
echo "		}"	>> abbrevations.lex
echo "		len = strlen(yytext);"	>> abbrevations.lex
echo "		strncat(str,yytext,len);"	>> abbrevations.lex
echo "		printf(\"%s\",str);"	>> abbrevations.lex
echo "		}"	>> abbrevations.lex
echo "		"	>> abbrevations.lex

done;
