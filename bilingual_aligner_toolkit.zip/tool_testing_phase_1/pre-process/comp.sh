flex $1.lex
gcc -o $1.out lex.yy.c -lfl
