rm abbrevations.lex
echo "%{" > abbrevations.lex
echo "#include<string.h>" >> abbrevations.lex
echo "int len;" >> abbrevations.lex
echo "char *s, str[1000];" >> abbrevations.lex
echo "%}"  >> abbrevations.lex
echo "%%" >>  abbrevations.lex

sh generate-abbrevation-lex.sh 
echo  "%%"   >> abbrevations.lex

./comp.sh abbrevations 
