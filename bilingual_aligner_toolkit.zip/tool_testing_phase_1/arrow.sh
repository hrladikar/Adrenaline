# eng_sen_ and hin_sen_ should be in same folder.. Path should be provided properly.. files will be generated where run_sentence_alignment.sh file present.. else change path in the sh file..

for i in `seq 1 912`;
do
	bash run_sentence_alignment.sh /eng_sen_$i /hin_sen_$i;
done
