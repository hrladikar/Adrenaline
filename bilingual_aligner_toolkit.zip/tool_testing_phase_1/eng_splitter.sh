sed 's/[.!?]  */&\n/g' < $1 | sed  '/^$/d' > eng
grep -v "^$" eng > Eng.txt
rm eng
