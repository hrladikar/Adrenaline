#To run champollion
sh eng_splitter.sh $1 
sh hnd_splitter.sh $2
sh run_sentence_alignment.sh eng.txt hnd.txt
