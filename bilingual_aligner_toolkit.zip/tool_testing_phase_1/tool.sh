python3 hin_ptagcrawl2.py 

echo "HINDI CORPUS CRAWLED"
echo "Step 1: Copy the content of output html file into a text file"
echo "Step 2: Rename the text file as para_hin"
echo "Step 3: Remove the unnecessary symbols or characters using Find and Replace"
echo " Steps Completed ? type enter to split Corpus ..."
read enter
if [[ $enter == enter ]]; then
	bash hnd_splitter.sh para_hin
fi

python3 eng_ptagcrawl2.py 

echo "ENGLISH CORPUS CRAWLED"
echo "Step 1: Copy the content of output html file into a text file"
echo "Step 2: Rename the text file as para_eng"
echo "Step 3: Remove the unnecessary symbols or characters using Find and Replace"
echo " Steps Completed ? type enter to split Corpus ..."
read enter
if [[ $enter == enter ]]; then
	bash eng_splitter.sh para_eng
fi


echo " Enabling Champollion ... "
echo "Acquiring statistical data"
#-----remove empty lines in both files---
echo "remove empty segments (\n\n) from sentence split files (Eng.txt Hnd.txt)"
echo "Segments Arranged? Type enter to run Champollion"
read enter
if [[ $enter == enter ]]; then
	bash run_sentence_alignment.sh Eng.txt Hnd.txt
	echo " Producing Aligned file.. "
	./align-eng-hin.out align_Eng.txt.txt Hnd.txt Eng.txt Aligned_en_hn.txt;
fi
