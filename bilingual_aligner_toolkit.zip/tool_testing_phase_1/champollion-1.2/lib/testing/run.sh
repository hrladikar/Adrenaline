gcc -o convert-to-champillion.out convert-to-champillion.c 

#./convert-to-champillion.out $HOME_anu_test/Anu_data/canonical_form_dictionary/dictionaries/default-iit-bombay-shabdanjali-dic_smt.txt > dic.txt
./convert-to-champillion.out $1 > dic.txt

#cp ../ehdict.utf8.txt .

utf8_wx ehdict.utf8.txt  > ehdict.wx.txt

sed 's/ $//g'  ehdict.wx.txt  > ehdict.wx.txt_tmp
cat ehdict.wx.txt_tmp >  ehdict.wx.txt_tmp1

export LC_ALL=C

sort -u ehdict.wx.txt_tmp1 > ehdict.wx.txt_tmp2

cut -f1 -d' '  ehdict.wx.txt_tmp2 > ehdict.wx.txt_tmp2_eng
cut -f3 -d' '  ehdict.wx.txt_tmp2 > ehdict.wx.txt_tmp2_hnd

$HOME_anu_test/Anu_data/canonical_form_dictionary/./get_canonical_form-dic.out  ehdict.wx.txt_tmp2_hnd > ehdict.wx.txt_tmp2_hnd.canonical_form

sed 's/KIFc/KIzc/g'  ehdict.wx.txt_tmp2_hnd.canonical_form   > ehdict.wx.txt_tmp3_hnd.canonical_form 
~/FONTS/converter/./wx_utf8.out  < ehdict.wx.txt_tmp3_hnd.canonical_form > ehdict.utf8.txt_tmp2_hnd.canonical_form 
#wx_utf8   ehdict.wx.txt_tmp3_hnd.canonical_form > ehdict.utf8.txt_tmp2_hnd.canonical_form 

paste ehdict.wx.txt_tmp2_eng ehdict.utf8.txt_tmp2_hnd.canonical_form > ehdict.utf8.txt_tmp

sed 's/\t/ <> /g'  ehdict.utf8.txt_tmp  > ehdict.utf8.txt_tmp1

export LC_ALL=C
sort -u ehdict.utf8.txt_tmp1 > ehdict.utf8.txt_new

