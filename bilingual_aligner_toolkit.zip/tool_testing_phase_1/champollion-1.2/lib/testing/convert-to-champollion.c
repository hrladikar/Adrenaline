//Added by Roja(02-05-12)
//Program to generate text in champollion dic format

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

int main(int argc, char* argv[])
{

   size_t  len=0, len1=0;
   char    eng_wrd[1000], mng[1000], mng1[1000], *value;
   char    * line=NULL;
   FILE    *fp;
   int     i;

   fp=fopen(argv[1], "r");
   if(fp==NULL)  printf("could not open file ");

   while (getline(&line, &len, fp) != -1)
   {
       sscanf(line, "%s\t%s\n", &eng_wrd[i], &mng[i]);
       value=mng; 
       while(strchr(value, '/')) 
         {   
             len1=strcspn(value, "/");
             strncpy(mng1, value, len1);
             mng1[len1]='\0';  value=value+len1+1; 
             printf("%s <> %s\n", eng_wrd, mng1);
         }	     
         if(!strchr(value, '/'))    
             printf("%s <> %s\n", eng_wrd, value);
   } 
 fclose(fp);
}
